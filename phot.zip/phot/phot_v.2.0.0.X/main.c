/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.6
        Device            :  PIC16F15325
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <stdio.h>

uint16_t dd;
unsigned long count = 0;
//unsigned int totaltime;
//unsigned int rpm = 0;

void TMR0_on()
{
        PIE0bits.TMR0IE = 1;
    PR0 = 250;
    T0CON0bits.T0EN = 1;
    T0CON0bits.T016BIT = 0;
    T0CON0bits.T0OUTPS = 0b0111;
    T0CON1bits.T0CS = 0b010;
    T0CON1bits.T0ASYNC = 1;
    T0CON1bits.T0CKPS = 0;
    PIR0bits.TMR0IF = 0;
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;
    
//    PIE0bits.TMR0IE = 1;
//    PR0 = 250;
//    T0CON0bits.T0EN = 1;
//    T0CON0bits.T016BIT = 0;
//    T0CON0bits.T0OUTPS = 0b1011;
//    T0CON1bits.T0CS = 0b010;
//    T0CON1bits.T0ASYNC = 1;
//    T0CON1bits.T0CKPS = 0b1011;
//    PIR0bits.TMR0IF = 0;
//    INTCONbits.PEIE = 1;
//    INTCONbits.GIE = 1;
}

//pp276
//void TMR1_on()
//{
//    T1CONbits.CKPS = 0b00;
//    T1CONbits.nSYNC = 0b1;
//    T1CONbits.RD16 = 0b1;
//    T1CONbits.ON = 0b0;
//    T1CLKbits.CS = 0b0101;
//    PIE4bits.TMR1IE = 0b1;
//    PR1 = 50;
//}

/*
                         Main application
 */

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
//    SPI1_Initialize();
//    SPI1_Open(SPI1_DEFAULT);

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    TMR0_on();
    while (1){
        LED_SetHigh();
         dd = ADC_GetConversion(Input);
         //���˗���������dd�̒l��������Bif�͔��˂����l�ȏ�ɂȂ�Ǝ��s
         if(512 > dd){
             printf("%lu\n",count);
             count = 0;
        }
         __delay_ms(100);
    }
}

//void __interrupt() timer1_isr(void)
//{
//     if (TMR0IF == 1) {
//          TMR0IF = 0 ;
//    }
//}

void __interrupt() timer0_isr(void)
{
     if (TMR0IF == 1){
         LED_SetLow();
         count++;
         TMR0IF = 0 ;
    }
}

//void __interrupt() timer1_isr(void)
//{
//    if(PIR4bits.TMR1IF){
//        LED_SetHigh();
//        PIR4bits.TMR1IF = 0;
//    }
//}

//void __interrupt() isr(void)
//{
//    if(PIR4bits.TMR1IF){
//        
//        PIR4bits.TMR1IF = 0;
//    }
//}
/**
 End of File
*/