/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.6
        Device            :  PIC16F15325
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <stdio.h>

//�f�W�^���l�̓d���i�[�p
uint16_t dd;
unsigned long count = 0;

//�^�C�}�[���W�X�g
void TMR0_on()
{
    PIE0bits.TMR0IE = 1;
    T0CON0bits.T0EN = 1;
    T0CON0bits.T016BIT = 0;
    T0CON0bits.T0OUTPS = 0b0000;
    T0CON1bits.T0CS = 0b101;
    T0CON1bits.T0ASYNC = 1;
    T0CON1bits.T0CKPS = 0b0000;
    PIR0bits.TMR0IF = 0;
    INTCONbits.PEIE = 1;
    INTCONbits.GIE = 1;
}

/*
                         Main application
 */

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
//    SPI1_Initialize();
//    SPI1_Open(SPI1_DEFAULT);

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    //�^�C�}�[�J�n
    TMR0_on();
    while (1){
        LED_1_SetLow();
        //USB�V���A���ϊ����W���[����count�𑗐M
        printf("%lu\n",count);
        __delay_ms(0.5);
    }
}

void __interrupt() timer0_isr(void)
{
    //�t���O���m�F
     if (TMR0IF == 1){
         LED_1_SetHigh();
         //�A�i���O�d����10bit�̃f�W�^���ɕϊ�
         dd = ADC_GetConversion(Input);
         //���˗���������dd�̒l��������Bif�͔��˂����l�ȏ�ɂȂ�Ǝ��s
         if(300 > dd){
            count++;
            count = 0;
        }
         count++;
         //�t���O���Z�b�g
         TMR0IF = 0 ;
    }
}

/**
 End of File
*/